# Free Video Downloader

A responsive FastAPI web app for downloading videos from supported YouTube, Instagram, and TikTok URLs when the content is accessible and you have the right to save it. Built to run locally on Android using Termux, with optional Cloudflare Tunnel access.

## Features

- Responsive dark UI, URL validation, loading feedback and helpful errors
- Python backend using `yt-dlp`
- File delivery through a short-lived download token
- Basic concurrency limit, URL allowlist, file size limit and automatic cleanup
- Health check at `/health`
- GitHub-ready structure

## Important legal and platform notes

Only download videos you own, have permission to download, or are otherwise legally entitled to save. Respect copyright, privacy, and each platform's terms. This project does not bypass DRM, paywalls, or access controls. Private, login-protected, age-restricted, or platform-blocked videos may not work. Platform support can change without notice.

Do not expose this server publicly unless you understand the risks. Anyone with the public tunnel URL can reach the app. For production use, add authentication, rate limiting, stronger abuse protection, and persistent job management. Quick tunnels are for development/testing, not production hosting.

## Run in Termux (Android)

Use a current Termux build. In Termux:

```bash
pkg update && pkg upgrade -y
pkg install python ffmpeg git cloudflared -y
```

If `cloudflared` is unavailable in your configured Termux repositories, install it from Cloudflare's official installation instructions for your architecture.

Copy/clone this repository, then:

```bash
cd free-video-downloader
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:8080` in your phone browser. Keep Termux open while using the app.

### If you downloaded a ZIP instead of cloning

Extract it, enter the extracted `free-video-downloader` folder, and run the same setup commands above.

## Public URL with Cloudflare Tunnel

In a second Termux session, run:

```bash
cloudflared tunnel --url http://127.0.0.1:8080
```

Cloudflare will print a temporary `https://....trycloudflare.com` address. Open that exact address. The URL changes when the quick tunnel restarts. Keep both sessions running.

## GitHub upload

```bash
git init
git add .
git commit -m "Initial Free Video Downloader app"
```

Create an empty repository on GitHub, then follow GitHub's instructions to add its remote and push your branch. Do not commit secrets or private credentials.

## Common issues

- **`No module named ...`**: activate `.venv` and run `pip install -r requirements.txt`.
- **`Address already in use`**: another process is using port 8080. Stop it or change the port in `app.py`.
- **`ffmpeg not found`**: run `pkg install ffmpeg`.
- **Video extraction fails**: update `yt-dlp` with `python -m pip install -U yt-dlp`. The platform may have changed, blocked the request, or require authentication.
- **Cloudflare URL does not open**: confirm the app is running locally first; then restart the tunnel and use the new URL.
- **Phone sleeps and the site stops**: Android may suspend Termux. Keep Termux active and review Android battery settings for Termux.

## Project files

```text
free-video-downloader/
├── app.py
├── requirements.txt
├── README.md
├── redeem.md
├── .env.example
├── .gitignore
├── templates/
│   └── index.html
├── static/
│   ├── css/style.css
│   └── js/app.js
└── downloads/
    └── .gitkeep
```

## Security notes

This is a development starter, not a hardened public service. Download work runs in a worker thread with a request timeout, but thread cancellation does not necessarily stop an already-running extractor. For public production use, move downloads to a managed worker queue, enforce per-IP rate limits, add authentication, and run behind a properly configured production deployment.
