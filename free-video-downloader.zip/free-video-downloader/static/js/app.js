const form = document.querySelector("#download-form");
const urlInput = document.querySelector("#video-url");
const downloadBtn = document.querySelector("#download-btn");
const pasteBtn = document.querySelector("#paste-btn");
const result = document.querySelector("#result");

function showMessage(message, kind = "error", link = null, linkText = "Download video") {
  result.replaceChildren();
  result.hidden = false;
  result.className = `result ${kind}`;
  const text = document.createElement("div");
  text.textContent = message;
  result.appendChild(text);
  if (link) {
    const anchor = document.createElement("a");
    anchor.href = link;
    anchor.textContent = linkText;
    anchor.setAttribute("download", "");
    result.appendChild(document.createElement("br"));
    result.appendChild(anchor);
  }
}
function setLoading(loading) {
  downloadBtn.disabled = loading;
  downloadBtn.classList.toggle("loading", loading);
}
pasteBtn.addEventListener("click", async () => {
  try {
    if (!navigator.clipboard?.readText) throw new Error("Clipboard unavailable");
    const value = await navigator.clipboard.readText();
    if (value) urlInput.value = value.trim();
    urlInput.focus();
  } catch {
    urlInput.focus();
    showMessage("Clipboard access isn't available here. Long-press the field and choose Paste.", "error");
  }
});
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  result.hidden = true;
  const url = urlInput.value.trim();
  if (!url) {
    showMessage("Paste a video URL first.");
    urlInput.focus();
    return;
  }
  setLoading(true);
  showMessage("Checking the link and preparing your download. This may take a little while.", "success");
  try {
    const body = new URLSearchParams({ url });
    const response = await fetch("/api/download", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
      body
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.detail || "Unable to process this link.");
    showMessage(`Your video is ready: ${data.title}`, "success", data.download_url);
  } catch (error) {
    showMessage(error.message || "A network error occurred. Please try again.");
  } finally {
    setLoading(false);
  }
});
