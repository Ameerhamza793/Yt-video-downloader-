# Redeem / Release Notes

## Project
**Free Video Downloader** — a self-hosted web interface for videos the user is authorized to download.

## Setup checklist
- [ ] Install Python and FFmpeg in Termux.
- [ ] Install Python dependencies from `requirements.txt`.
- [ ] Start the app and confirm `http://127.0.0.1:8080/health` returns `{"status":"ok","service":"Free Video Downloader"}`.
- [ ] Test only URLs for content you own or have permission to save.
- [ ] Start Cloudflare Tunnel only when public access is needed.
- [ ] Review logs and stop the app/tunnel when finished.

## Usage
Paste a supported HTTPS URL from YouTube, Instagram, or TikTok into the home page and submit. If the source allows extraction and the format is available, the page displays a temporary download link.

## Limitations
- This project does not bypass DRM, private access controls, paywalls, or login requirements.
- Platform extraction may break when websites change.
- Quick Tunnel URLs are temporary and are not production hosting.
- The starter does not provide accounts, a database, persistent jobs, or production-grade abuse prevention.

## Responsible use
Use only for lawful, authorized downloads. Respect creator rights, privacy, copyright law, and platform terms.
