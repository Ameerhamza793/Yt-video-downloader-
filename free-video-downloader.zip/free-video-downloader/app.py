from __future__ import annotations

import asyncio
import ipaddress
import os
import re
import secrets
import shutil
import socket
import time
from pathlib import Path
from urllib.parse import urlparse

from fastapi import FastAPI, Form, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from yt_dlp import YoutubeDL

APP_DIR = Path(__file__).resolve().parent
DOWNLOAD_DIR = APP_DIR / "downloads"
DOWNLOAD_DIR.mkdir(exist_ok=True)
MAX_AGE_SECONDS = int(os.getenv("DOWNLOAD_MAX_AGE_SECONDS", "3600"))
MAX_ACTIVE_DOWNLOADS = int(os.getenv("MAX_ACTIVE_DOWNLOADS", "2"))
MAX_URL_LENGTH = 2048
ALLOWED_HOSTS = {
    "youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be",
    "instagram.com", "www.instagram.com",
    "tiktok.com", "www.tiktok.com", "vm.tiktok.com", "vt.tiktok.com",
}
active_downloads = 0
download_lock = asyncio.Lock()
app = FastAPI(title="Free Video Downloader", version="1.0.0")
app.mount("/static", StaticFiles(directory=APP_DIR / "static"), name="static")
templates = Jinja2Templates(directory=APP_DIR / "templates")


def validate_url(raw_url: str) -> str:
    url = raw_url.strip()
    if not url or len(url) > MAX_URL_LENGTH:
        raise HTTPException(status_code=400, detail="Enter a valid video URL.")
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname:
        raise HTTPException(status_code=400, detail="Use a full HTTPS video URL.")
    host = parsed.hostname.lower().rstrip(".")
    if host not in ALLOWED_HOSTS:
        raise HTTPException(
            status_code=400,
            detail="Supported sites are YouTube, Instagram and TikTok only."
        )
    if parsed.username or parsed.password:
        raise HTTPException(status_code=400, detail="URLs containing credentials are not allowed.")
    return url


def clean_old_files() -> None:
    now = time.time()
    for path in DOWNLOAD_DIR.iterdir():
        try:
            if path.is_file() and now - path.stat().st_mtime > MAX_AGE_SECONDS:
                path.unlink(missing_ok=True)
        except OSError:
            pass


def download_video(url: str) -> tuple[Path, dict]:
    """Download one permitted video into a per-request temporary folder."""
    request_dir = DOWNLOAD_DIR / secrets.token_hex(12)
    request_dir.mkdir(mode=0o700)
    opts = {
        "outtmpl": str(request_dir / "%(title).120B-%(id)s.%(ext)s"),
        "format": "best[ext=mp4]/best",
        "merge_output_format": "mp4",
        "noplaylist": True,
        "restrictfilenames": True,
        "quiet": True,
        "no_warnings": True,
        "socket_timeout": 20,
        "retries": 1,
        "fragment_retries": 1,
        "max_filesize": 500 * 1024 * 1024,
        "overwrites": False,
    }
    try:
        with YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
        candidates = [p for p in request_dir.iterdir() if p.is_file() and not p.name.endswith((".part", ".ytdl"))]
        if not candidates:
            raise RuntimeError("The site did not produce a downloadable file.")
        file_path = max(candidates, key=lambda p: p.stat().st_size)
        title = str(info.get("title") or file_path.stem)[:180]
        return file_path, {"title": title, "folder": request_dir}
    except Exception:
        shutil.rmtree(request_dir, ignore_errors=True)
        raise


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/health")
async def health():
    return {"status": "ok", "service": "Free Video Downloader"}


@app.post("/api/download")
async def api_download(url: str = Form(...)):
    global active_downloads
    validated = validate_url(url)
    clean_old_files()
    async with download_lock:
        if active_downloads >= MAX_ACTIVE_DOWNLOADS:
            raise HTTPException(status_code=429, detail="The downloader is busy. Try again shortly.")
        active_downloads += 1
    try:
        # yt-dlp is blocking; run it outside the event loop.
        file_path, info = await asyncio.wait_for(
            asyncio.to_thread(download_video, validated), timeout=240
        )
        token = secrets.token_urlsafe(24)
        # A token maps only to this exact generated file; no user path is accepted.
        DOWNLOADS[token] = {
            "path": file_path,
            "title": info["title"],
            "created": time.time(),
            "folder": info["folder"],
        }
        return JSONResponse({
            "ok": True,
            "title": info["title"],
            "download_url": f"/api/file/{token}",
            "filename": file_path.name,
        })
    except asyncio.TimeoutError:
        raise HTTPException(status_code=504, detail="Download timed out. Try a shorter video or another URL.")
    except HTTPException:
        raise
    except Exception as exc:
        message = str(exc).replace("\n", " ")[:240]
        raise HTTPException(
            status_code=422,
            detail=f"Could not download this URL. The site may require login, block access, or not support this video. Details: {message}"
        )
    finally:
        async with download_lock:
            active_downloads = max(0, active_downloads - 1)


DOWNLOADS: dict[str, dict] = {}


@app.get("/api/file/{token}")
async def get_file(token: str):
    item = DOWNLOADS.get(token)
    if not item:
        raise HTTPException(status_code=404, detail="Download link expired. Start again.")
    if time.time() - item["created"] > MAX_AGE_SECONDS or not item["path"].is_file():
        DOWNLOADS.pop(token, None)
        shutil.rmtree(item["folder"], ignore_errors=True)
        raise HTTPException(status_code=410, detail="Download link expired. Start again.")
    return FileResponse(
        path=item["path"],
        filename=item["path"].name,
        media_type="video/mp4" if item["path"].suffix.lower() == ".mp4" else "application/octet-stream",
    )


@app.exception_handler(HTTPException)
async def http_error_handler(request: Request, exc: HTTPException):
    if request.url.path.startswith("/api/"):
        return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=8080, reload=False)
